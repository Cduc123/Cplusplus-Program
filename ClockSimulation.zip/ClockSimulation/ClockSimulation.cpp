/*
    Project: Clock Simulation in C++
    Author: Christopher Duclervil
    Date:  September 27, 2024
    Description: This project simulates two clocks displaying the time in both 12-hour and 24-hour formats using OOP in C++.
    The program allows the user to set and display the clocks.

    File: main.cpp
*/

#include <iostream>
#include <iomanip>

using namespace std;

// Clock class definition
class Clock {
private:
    int hours;
    int minutes;
    int seconds;

    // function to keep time within correct bounds
    void validateTime() {
        if (seconds >= 60) {
            minutes += seconds / 60;
            seconds = seconds % 60;
        }
        if (minutes >= 60) {
            hours += minutes / 60;
            minutes = minutes % 60;
        }
        if (hours >= 24) {
            hours = hours % 24;
        }
    }

public:
    //   initialize clock to 00:00:00
    Clock() : hours(0), minutes(0), seconds(0) {}

    // Function to set time with validation
    void setTime(int h, int m, int s) {
        if (h >= 0 && h < 24 && m >= 0 && m < 60 && s >= 0 && s < 60) {
            hours = h;
            minutes = m;
            seconds = s;
        }
        else {
            cout << "Invalid time input. Please try again." << endl;
        }
    }

    // Function to display time in 12-hour format
    void display12HourFormat() const {
        int displayHours = hours % 12;
        if (displayHours == 0) displayHours = 12; // Special case for 12 AM/PM

        cout << setw(2) << setfill('0') << displayHours << ":"
            << setw(2) << setfill('0') << minutes << ":"
            << setw(2) << setfill('0') << seconds << " "
            << (hours < 12 ? "AM" : "PM") << endl;
    }

    // Function to display time in 24-hour format
    void display24HourFormat() const {
        cout << setw(2) << setfill('0') << hours << ":"
            << setw(2) << setfill('0') << minutes << ":"
            << setw(2) << setfill('0') << seconds << endl;
    }

    // Optionally add seconds and adjust time
    void addSeconds(int sec) {
        seconds += sec;
        validateTime();  // Adjust the time if seconds overflow
    }
};

// Function to display menu
void displayMenu() {
    cout << "1. Set time for both clocks\n";
    cout << "2. Display both clocks\n";
    cout << "3. Exit\n";
}

int main() {
    //  Two Clock instances
    Clock clock1, clock2;
    int choice;

    do {
        displayMenu();
        cin >> choice;

        if (choice == 1) {
            int h, m, s;
            cout << "Set time (hours, minutes, seconds):\n";
            cout << "Enter hours (0-23): ";
            cin >> h;
            cout << "Enter minutes (0-59): ";
            cin >> m;
            cout << "Enter seconds (0-59): ";
            cin >> s;

            clock1.setTime(h, m, s);  // Set time for the first clock
            clock2.setTime(h, m, s);  // Set time for the second clock

        }
        else if (choice == 2) {
            // Display clocks in 12-hour and 24-hour format
            cout << "Clock 1 (12-Hour Format): ";
            clock1.display12HourFormat();
            cout << "Clock 1 (24-Hour Format): ";
            clock1.display24HourFormat();

            cout << "\nClock 2 (12-Hour Format): ";
            clock2.display12HourFormat();
            cout << "Clock 2 (24-Hour Format): ";
            clock2.display24HourFormat();
            cout << endl;

        }
        else if (choice == 3) {
            cout << "Exiting program...\n";
        }
        else {
            cout << "Invalid choice. Please try again.\n";
        }

    } while (choice != 3);

    return 0;
}
