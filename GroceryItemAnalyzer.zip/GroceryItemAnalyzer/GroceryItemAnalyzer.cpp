#include <iostream>
#include <fstream>
#include <map>
#include <string>
#include <iomanip>

using namespace std;

class GroceryAnalyzer {
private:
    map<string, int> itemFrequencies;

    // Reads the input file and populates the item frequencies map
    void ReadFile(string fileName) {
        ifstream inputFile(fileName);
        string item;
        int count;

        if (inputFile.is_open()) {
            while (inputFile >> item >> count) {
                itemFrequencies[item] = count;
            }
            inputFile.close();
        } else {
            cout << "Error opening file: " << fileName << endl;
        }
    }

    // Backs up the frequencies to a file
    void BackupFrequencies(string fileName) {
        ofstream outputFile(fileName);
        if (outputFile.is_open()) {
            for (auto const& pair : itemFrequencies) {
                outputFile << pair.first << " " << pair.second << endl;
            }
            outputFile.close();
        } else {
            cout << "Error creating backup file: " << fileName << endl;
        }
    }

public:
    // Constructor to initialize and populate the map from file
    GroceryAnalyzer(string inputFileName) {
        ReadFile(inputFileName);
        BackupFrequencies("frequency.dat");
    }

    // Option 1: Finds the frequency of a specific item
    int FindItemFrequency(string item) {
        if (itemFrequencies.find(item) != itemFrequencies.end()) {
            return itemFrequencies[item];
        } else {
            return 0; // Item not found
        }
    }

    // Option 2: Prints all items and their frequencies
    void PrintFrequencies() {
        cout << "Item Frequencies:" << endl;
        for (auto const& pair : itemFrequencies) {
            cout << pair.first << " " << pair.second << endl;
        }
    }

    // Option 3: Prints a histogram of item frequencies
    void PrintHistogram() {
        cout << "Item Histogram:" << endl;
        for (auto const& pair : itemFrequencies) {
            cout << pair.first << " ";
            for (int i = 0; i < pair.second; ++i) {
                cout << "*";
            }
            cout << endl;
        }
    }

    // Main menu for the program
    void DisplayMenu() {
        int choice;
        string item;

        do {
            cout << "1. Find item frequency" << endl;
            cout << "2. Print all frequencies" << endl;
            cout << "3. Print histogram" << endl;
            cout << "4. Exit" << endl;
            cout << "Enter your choice: ";
            cin >> choice;

            switch (choice) {
                case 1:
                    cout << "Enter item name: ";
                    cin >> item;
                    cout << item << " appears " << FindItemFrequency(item) << " times." << endl;
                    break;
                case 2:
                    PrintFrequencies();
                    break;
                case 3:
                    PrintHistogram();
                    break;
                case 4:
                    cout << "Exiting program." << endl;
                    break;
                default:
                    cout << "Invalid option, try again." << endl;
            }

        } while (choice != 4);
    }
};

int main() {
    GroceryAnalyzer analyzer("CS210_Project_Three_Input_File.txt.txt");
    analyzer.DisplayMenu();
    return 0;
}
