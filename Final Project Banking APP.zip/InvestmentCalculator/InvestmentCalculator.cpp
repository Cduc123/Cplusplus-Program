#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

int main() {
    // Declare variables for input
    double initialInvestmentAmount;
    double monthlyDeposit;
    double annualInterestRate;
    int numberOfYears;

    // Declare constants
    const int monthsInYear = 12;

    // Prompt user for input values
    cout << "Welcome to the Airgead Banking Investment Calculator!" << endl;
    cout << "Enter initial investment amount (in dollars): ";
    cin >> initialInvestmentAmount;
    cout << "Enter monthly deposit amount (in dollars): ";
    cin >> monthlyDeposit;
    cout << "Enter annual interest rate (as a percentage): ";
    cin >> annualInterestRate;
    cout << "Enter number of years to invest: ";
    cin >> numberOfYears;

    // Open a file for output
    ofstream outputFile("InvestmentSummary.txt");

    // Check if the output file opened successfully
    if (!outputFile) {
        cerr << "Error opening output file." << endl;
        return 1;
    }

    // Print a header to the output file
    outputFile << "Year    Opening Balance    Deposited Amount    Interest Earned    Closing Balance" << endl;

    // Initialize variables for calculations
    double currentBalance = initialInvestmentAmount;

    // Loop through each year
    for (int year = 1; year <= numberOfYears; year++) {
        // Initialize variables for this year's interest
        double yearEndInterest = 0;
        double openingBalance = currentBalance; // Capture opening balance

        // Loop through each month in this year
        for (int month = 1; month <= monthsInYear; month++) {
            // Calculate monthly interest rate
            double monthlyInterestRate = annualInterestRate / monthsInYear / 100;

            // Calculate interest for the month
            double monthEndInterest = currentBalance * monthlyInterestRate;

            // Update current balance (add deposit and interest)
            currentBalance = currentBalance + monthlyDeposit + monthEndInterest;

            // Accumulate the year-end interest
            yearEndInterest += monthEndInterest;
        }

        // Print the year-end summary to the output file
        outputFile << fixed << setprecision(2);
        outputFile << year << "    "
            << openingBalance << "    "
            << monthlyDeposit * monthsInYear << "    "
            << yearEndInterest << "    "
            << currentBalance << endl;
    }

    // Close the output file
    outputFile.close();

    // Display a message to the user
    cout << "Results have been saved to InvestmentSummary.txt." << endl;

    return 0;
}
